"use strict";
use(function () {
    var link = {};
    var buttonLink = granite.resource.properties["sorryButtonLink"];

    if(buttonLink && buttonLink.startsWith("/content/")) {
		buttonLink = buttonLink + ".html";
    } 
    link.buttonLink = buttonLink;   
    return link;
});